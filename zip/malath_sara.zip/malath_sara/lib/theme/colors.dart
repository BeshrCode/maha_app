



import 'dart:ui';

const bgColor = Color(0xfff5f5f5);
