import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../../app_pages.dart';
import '../../theme/colors.dart';
import '../controller/my_patients_controller.dart';

class MyPatientsPage extends GetWidget<MyPatientsController> {
  const MyPatientsPage({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
         appBar: AppBar(
           title: const Text('Hi, Dr. Abdullah',style: TextStyle(
             fontFamily: 'Inter',
             fontWeight: FontWeight.w700,
             color: Color(0xff321F5C)
           ),),
        actions: [
          Container(
            margin: const EdgeInsets.only(
              right: 10,
              left: 10,
            ),
            child: InkWell(
              onTap: () {
              },
              child: const Icon(Icons.settings),
            ),
          ),
        ],
        surfaceTintColor: bgColor,
        backgroundColor: bgColor,
      ),
      body: _body(context),
    );

  }


  Column _body(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 30, // Fixed height for the top list
          child: _topList(),
        ),
        const SizedBox(height: 10),
        const Divider(),
        searchBar(),
        Row(
          children: [
            IconButton(onPressed: () {
              controller.showFilterDialog(context);
            }, icon: const Icon(Icons.filter_list)),
            const Text('Filter'),
          ],
        ),
        const SizedBox(height: 20),
        _list(),
      ],
    );
  }

  Widget _topList() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: GetBuilder<MyPatientsController>(
        builder: (controller) =>
            ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: controller.items.length,
              physics: const NeverScrollableScrollPhysics(),
              // Disable scrolling
              shrinkWrap: true,
              // Allow the ListView to take only the space it needs
              itemBuilder: (BuildContext context, int index) {
                return GestureDetector(
                  onTap: () {
                    controller.selectItem(index);
                  },
                  child: Obx(() {
                    return Container(
                      height: 20,
                      width: 100,
                      decoration: BoxDecoration(
                        color: controller.selectedIndex == index ? const Color(
                            0xffD7C4FC) : Colors.white,
                        borderRadius: BorderRadius.circular(30),
                      ),
                      alignment: Alignment.center,
                      // Center the text inside the container
                      child: Text(
                        controller.items[index],
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                          color: controller.selectedIndex == index ? Colors
                              .white : const Color(0xffBAC5FC),
                        ),
                      ),
                    );
                  }),
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(width: 10);
              },
            ),
      ),
    );
  }

  Widget searchBar() {
    return Container(
      margin: const EdgeInsets.only(
        right: 20,
        left: 20,
        top: 20,
        bottom: 10
      ),

      height: 40,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [
          BoxShadow(
            color: Colors.grey,
            blurStyle: BlurStyle.normal,
            offset: Offset(-1, 2),
            spreadRadius: 0,
            blurRadius: 1
          )
        ],
      ),
      child: ListTile(
        autofocus: true,
        trailing: const FaIcon(FontAwesomeIcons.search,size: 20,),
        subtitle: const Text(''),
        isThreeLine: true,
        title: TextField(
          maxLines: 1,
          decoration: InputDecoration(
            hintText: 'Search',
            filled: true,
            fillColor: Colors.transparent,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ),
    );
  }
  Expanded _list(){
    return Expanded(
      flex: 7,
      child: ListView.separated(
        separatorBuilder: (context, index) {
          return const SizedBox(width :10,height:10);
        },
        itemCount: 10, itemBuilder: (BuildContext context, int index) {
        return InkWell(
          onTap: () {
            Get.toNamed(AppPages.patient_info_page);
          },
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 0,
                  blurRadius: 1,
                  offset: const Offset(0, 0), // changes the position of the shadow
                ),
              ],
            ),
            child:  ListTile(
              title: Text(
                'Sara Mohammed',
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w500,
                ),
              ),
              subtitle: Text(
                'Panic disorder',
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: 12,
                  fontFamily: 'Inter',
                ),
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Image.asset('assets/icons/vector_right.png'),
                  Text(
                    '2 days ago',
                    style: TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 12,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },),
    );
  }
}
