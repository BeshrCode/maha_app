package com.example.malath_sara

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
